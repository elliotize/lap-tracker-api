defmodule AppName.LayoutView do
  use AppName.Web, :view
end
