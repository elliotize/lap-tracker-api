defmodule AppName.PageView do
  use AppName.Web, :view
end
