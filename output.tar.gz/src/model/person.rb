require 'sequal'

class Person < Sequel::Model
end