ExUnit.start

Ecto.Adapters.SQL.Sandbox.mode(AppName.Repo, :manual)

