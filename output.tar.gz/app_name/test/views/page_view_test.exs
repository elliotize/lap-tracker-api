defmodule AppName.PageViewTest do
  use AppName.ConnCase, async: true
end
