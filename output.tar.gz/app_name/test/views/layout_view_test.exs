defmodule AppName.LayoutViewTest do
  use AppName.ConnCase, async: true
end
