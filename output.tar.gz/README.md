# Rocket Fuel
## Local Docker cluster
### Start Cluster
```
moonshot local-create
```

## AWS ASG cluster
### Start Cluster
```
moonshot create
```
